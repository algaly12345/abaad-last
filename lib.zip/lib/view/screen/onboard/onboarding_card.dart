import 'package:abaad_flutter/helper/responsive_helper.dart';
import 'package:abaad_flutter/util/dimensions.dart';
import 'package:abaad_flutter/util/images.dart';
import 'package:abaad_flutter/util/styles.dart';
import 'package:abaad_flutter/view/screen/onboard/on_boarding_data.dart';
import 'package:abaad_flutter/view/screen/test.dart';
import 'package:flutter/material.dart';

class OnBoardingCard extends StatelessWidget {
  const OnBoardingCard({
     super.key,
     key_local,
     required this.onboardingContent,
     required this.currentPage,
     required this.pageController,
  });
  //
  final int currentPage;
  final PageController pageController;
  final OnboardingModel onboardingContent;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [

        Container(
          child: Stack(
            // alignment: AlignmentDirectional.center,
            children: [

              Container(


                child: ClipPath(
                  clipper: MyClipper(),
                  child: Container(
                    child: Image.asset(
                      Images.rectangle1,
                      width: double.infinity,
                      height: ResponsiveHelper.getHeight(context) * 0.64,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),

              SizedBox(
                height: ResponsiveHelper.getHeight(context) * 0.66,
                child: ClipPath(
                  clipper: MyClipper(),
                  child: Container(
                    child: Image.asset(
                      Images.rectangle2,
                      width: double.infinity,
                      height: ResponsiveHelper.getHeight(context) * 0.66,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),

              Align(
                alignment: Alignment.topCenter,

                child: ClipPath(
                  clipper: MyClipper(),
                  child: Container(
                    child: Image.asset(
                      onboardingContent.image,
                      width: double.infinity,
                      height: ResponsiveHelper.getHeight(context) * 0.62,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),


        Padding(
          padding: const EdgeInsets.only(right: 12,left: 12),
          child: Text(
            onboardingContent.title,
            textAlign: TextAlign.center,
            style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeDefault)
          ),
        ),
      ],
    );
  }
}
